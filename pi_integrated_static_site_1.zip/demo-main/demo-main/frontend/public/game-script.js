document.addEventListener('DOMContentLoaded', () => {
  console.log('Game script loaded.');

  // Initialize Pi SDK
  Pi.init({
    version: "2.0",
    sandbox: true // Use sandbox mode for testing
  });

  // Authenticate with Pi Network on game start
  Pi.authenticate([], onAuthenticate, onAuthenticateError);

  function onAuthenticate(auth) {
    console.log('Pi authentication successful:', auth);
    // You can use the 'auth' object here for user-specific actions
    // For example, display the user's Pi username or ID
    // alert(`Welcome, ${auth.user.username}!`);
  }

  function onAuthenticateError(error) {
    console.error('Pi authentication failed:', error);
    // Handle authentication errors, e.g., display a message to the user
    // alert('Failed to authenticate with Pi Network.');
  }

  // Placeholder for game logic or other integrations
  // Since no game script was provided, this is a basic setup.
});

