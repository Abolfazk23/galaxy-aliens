Galaxy Aliens game integrated.
Open game.html in Pi Browser to run.
Offline, uses localStorage to store π and lives in sandbox.
